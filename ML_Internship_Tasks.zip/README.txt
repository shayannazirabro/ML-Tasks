
Machine Learning Internship Tasks
=================================

Task 3: Housing Price Prediction
---------------------------------
- Dataset: California Housing (sklearn)
- Model: Linear Regression
- Steps:
    * Data loading
    * Train-test split
    * Feature scaling
    * Model training
    * Evaluation using MSE and R2 score

Run:
    python housing_price_prediction.py

Task 4: Iris Flower Classification
-----------------------------------
- Dataset: Iris (sklearn)
- Model: K-Nearest Neighbors (KNN)
- Steps:
    * Data loading
    * Train-test split
    * Feature scaling
    * Model training
    * Evaluation using accuracy and classification report

Run:
    python iris_classification.py

Requirements:
    pip install pandas scikit-learn
